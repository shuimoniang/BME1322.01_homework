# Assignment 2 Data — MNIST

本目录为 Assignment 2 提供标准 MNIST 手写数字数据集，共 **70,000** 张 28×28 灰度图：训练集 60,000 张，测试集 10,000 张。

## 文件

| 文件 | 内容 | 样本数 | 形状 |
|------|------|-------:|------|
| `train-images-idx3-ubyte.gz` | 训练集图像 | 60,000 | 60000 × 28 × 28 |
| `train-labels-idx1-ubyte.gz` | 训练集标签 | 60,000 | 60000 |
| `t10k-images-idx3-ubyte.gz` | 测试集图像 | 10,000 | 10000 × 28 × 28 |
| `t10k-labels-idx1-ubyte.gz` | 测试集标签 | 10,000 | 10000 |

- 图像像素值范围为 `0–255`。
- 标签为数字 `0–9`。
- 所有文件均为标准 MNIST IDX 格式的 gzip 压缩包。

## 来源

数据镜像：

```text
https://storage.googleapis.com/cvdf-datasets/mnist/train-images-idx3-ubyte.gz
https://storage.googleapis.com/cvdf-datasets/mnist/train-labels-idx1-ubyte.gz
https://storage.googleapis.com/cvdf-datasets/mnist/t10k-images-idx3-ubyte.gz
https://storage.googleapis.com/cvdf-datasets/mnist/t10k-labels-idx1-ubyte.gz
```

数据用于课程教学。若在报告或代码中引用数据集，请注明 MNIST 数据来源。

## 校验值

| 文件 | SHA-256 |
|------|---------|
| `train-images-idx3-ubyte.gz` | `440fcabf73cc546fa21475e81ea370265605f56be210a4024d2ca8f203523609` |
| `train-labels-idx1-ubyte.gz` | `3552534a0a558bbed6aed32b30c495cca23d567ec52cac8be1a0730e8010255c` |
| `t10k-images-idx3-ubyte.gz` | `8d422c7b0a1c1c79245a5bcf07fe86e33eeafee792b84584aec276f5a2dbc4e6` |
| `t10k-labels-idx1-ubyte.gz` | `f7ae60f92e00ec6debd23a6088c31dbd2371eca3ffa0defaefb259924204aec6` |
